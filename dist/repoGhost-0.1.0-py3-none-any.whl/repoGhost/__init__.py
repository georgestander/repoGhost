"""
RepoGhost - A tool for generating summaries of Git repositories
"""

__version__ = "0.1.0"

from .cli import main

__all__ = ["main"]